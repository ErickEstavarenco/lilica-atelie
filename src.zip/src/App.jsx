export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-emerald-50">
      <h1 className="text-5xl font-bold text-emerald-700">
        Lilica Ateliê 🌿
      </h1>
    </div>
  )
}
